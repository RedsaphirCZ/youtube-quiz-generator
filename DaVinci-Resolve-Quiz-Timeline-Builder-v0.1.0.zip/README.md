# DaVinci Resolve Quiz Timeline Builder

This Resolve 21+ script reads the existing `QuizDataset` JSON format and creates a paired timeline structure for every question:

```text
Q01 QUESTION  | neutral question and options
Q01 ANSWER    | correct answer highlight, then explanation
Q02 QUESTION
Q02 ANSWER
```

Blue `QUESTION` clips control thinking time. Green `ANSWER` clips control answer/explanation time. Both are ordinary Fusion Composition clips, so their edges can be trimmed directly on the Edit timeline.

## Install

Run `install.ps1`, restart DaVinci Resolve, and open:

```text
Workspace > Scripts > Quiz Timeline Builder
```

The installer copies one self-contained Lua file into your per-user Resolve Scripts folder. It does not require Python, packages, or network access.

## Use

1. Open a Resolve project and timeline.
2. Select an unlocked video track and place the playhead where the quiz should begin.
3. Open Quiz Timeline Builder from the Workspace menu.
4. Choose a compatible JSON file and set the number of questions.
5. Click **Build Timeline Clips**.
6. Trim each blue question clip and green answer clip to taste.

Resolve currently creates Fusion compositions using its configured standard generator duration. The builder keeps each pair adjacent and advances from the actual inserted clip length, so the first generated layout is gap-free. Trimming is intentionally left to the editor.

## Supported JSON

The builder directly supports the repository's two question types:

- `mcq`: `question`, `options`, zero-based `correctIndex`, and optional `explanation`.
- `number`: `question`, numeric `target`, optional unit/display fields, and optional `explanation`.

See `sample-quiz.json` and `quiz-timeline.schema.json`.

## Generated behavior

- The answer clip starts with the same neutral question/options state as the end of the question clip.
- At frames 4–12, the correct option highlights while wrong options dim.
- At frames 16–26, the explanation panel and text appear.
- A progress rail, question badge, bordered prompt card, letter chips, and subtle ambient color fields create a finished broadcast-style layout without external assets.
- The answer state adds an outlined green selection, a `CORRECT` tag, and a dedicated `WHY IT'S RIGHT` panel.
- Timeline markers identify every question and answer boundary.
- Clip colors and names make the paired structure easy to scan.

The visual palette and normalized layout are defined near the middle of `Quiz Timeline Builder.lua` and can later become user-selectable themes.
